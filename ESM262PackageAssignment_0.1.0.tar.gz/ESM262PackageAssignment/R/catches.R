#' Sample data for fisheries_summary function
#'
#' catches - A matrix with number of each fish species caught by fishery
#'
#' @format A matrix with rownames as fish species names and columnnames as fishery names
#'
#'
"catches"
